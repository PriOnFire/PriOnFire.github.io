import { useEffect, useState } from "react";

export function ThemeToggle() {
  const [theme, setTheme] = useState<"glass" | "dark">("dark");

  useEffect(() => {
    const savedTheme = localStorage.getItem("clickflow-theme") as "glass" | "dark" || "glass";
    setTheme(savedTheme);
    document.documentElement.classList.remove("glass", "dark");
    document.documentElement.classList.add(savedTheme);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "glass" ? "dark" : "glass";
    setTheme(newTheme);
    localStorage.setItem("clickflow-theme", newTheme);
    document.documentElement.classList.remove("glass", "dark");
    document.documentElement.classList.add(newTheme);
  };

  return (
    <label className="switch">
      <input 
        id="input" 
        type="checkbox" 
        checked={theme === "dark"}
        onChange={toggleTheme}
      />
      <span className="slider round">
        <span className="sun-moon">
          <svg className="stars" viewBox="0 0 26 26">
            <circle id="star-1" className="star" cx="5" cy="5" r="2" />
            <circle id="star-2" className="star" cx="8" cy="18" r="1" />
            <circle id="star-3" className="star" cx="15" cy="22" r="1.5" />
            <circle id="star-4" className="star" cx="22" cy="6" r="2" />
          </svg>
          <svg id="moon-dot-1" className="moon-dot" viewBox="0 0 10 10">
            <circle cx="5" cy="5" r="5" />
          </svg>
          <svg id="moon-dot-2" className="moon-dot" viewBox="0 0 10 10">
            <circle cx="5" cy="5" r="5" />
          </svg>
          <svg id="moon-dot-3" className="moon-dot" viewBox="0 0 10 10">
            <circle cx="5" cy="5" r="5" />
          </svg>
          <svg id="light-ray-1" viewBox="0 0 50 50">
            <circle cx="25" cy="25" r="20" />
          </svg>
          <svg id="light-ray-2" viewBox="0 0 50 50">
            <circle cx="25" cy="25" r="20" />
          </svg>
          <svg id="light-ray-3" viewBox="0 0 50 50">
            <circle cx="25" cy="25" r="20" />
          </svg>
          <svg id="cloud-1" className="cloud-light" viewBox="0 0 40 20">
            <ellipse cx="20" cy="10" rx="20" ry="10" />
          </svg>
          <svg id="cloud-2" className="cloud-light" viewBox="0 0 20 10">
            <ellipse cx="10" cy="5" rx="10" ry="5" />
          </svg>
          <svg id="cloud-3" className="cloud-light" viewBox="0 0 30 15">
            <ellipse cx="15" cy="7.5" rx="15" ry="7.5" />
          </svg>
          <svg id="cloud-4" className="cloud-dark" viewBox="0 0 40 20">
            <ellipse cx="20" cy="10" rx="20" ry="10" />
          </svg>
          <svg id="cloud-5" className="cloud-dark" viewBox="0 0 20 10">
            <ellipse cx="10" cy="5" rx="10" ry="5" />
          </svg>
          <svg id="cloud-6" className="cloud-dark" viewBox="0 0 30 15">
            <ellipse cx="15" cy="7.5" rx="15" ry="7.5" />
          </svg>
        </span>
      </span>
    </label>
  );
}