import { motion } from "framer-motion";
import { Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  const handleNavClick = (path: string) => {
    const element = document.querySelector(path);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="glass-card border-t mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h3 className="text-xl font-bold gradient-text mb-4">ClickFlow</h3>
            <p className="text-foreground/70 text-sm">
              Moderne websites met geïntegreerde AI-automatisering en volledige branding voor lokale ondernemers.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <h4 className="font-semibold mb-4">Snelle Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="#about" 
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick("#about");
                  }}
                  className="text-foreground/70 hover:text-primary transition-colors cursor-pointer"
                >
                  Over Ons
                </a>
              </li>
              <li>
                <a 
                  href="#services" 
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick("#services");
                  }}
                  className="text-foreground/70 hover:text-primary transition-colors cursor-pointer"
                >
                  Diensten
                </a>
              </li>
              <li>
                <a 
                  href="#portfolio" 
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick("#portfolio");
                  }}
                  className="text-foreground/70 hover:text-primary transition-colors cursor-pointer"
                >
                  Portfolio
                </a>
              </li>
              <li>
                <a 
                  href="#contact" 
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick("#contact");
                  }}
                  className="text-foreground/70 hover:text-primary transition-colors cursor-pointer"
                >
                  Contact
                </a>
              </li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center space-x-2 text-foreground/70">
                <Mail className="h-4 w-4" />
                <span>info@clickflow.nl</span>
              </li>
              <li className="flex items-center space-x-2 text-foreground/70">
                <Phone className="h-4 w-4" />
                <span>+31 6 12345678</span>
              </li>
              <li className="flex items-center space-x-2 text-foreground/70">
                <MapPin className="h-4 w-4" />
                <span>Nederland</span>
              </li>
            </ul>
          </motion.div>
        </div>

        <div className="border-t border-border/50 mt-8 pt-8 text-center text-sm text-foreground/60">
          <p>&copy; {new Date().getFullYear()} ClickFlow. Alle rechten voorbehouden.</p>
        </div>
      </div>
    </footer>
  );
}