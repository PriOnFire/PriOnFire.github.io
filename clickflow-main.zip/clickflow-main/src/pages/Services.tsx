import { motion } from "framer-motion";
import { Code, Bot, Smartphone, Calendar, Workflow, Palette } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Link } from "react-router";

export default function Services() {
  const services = [
    {
      icon: Code,
      title: "Webdesign & Frontend Development",
      description: "Moderne, responsive websites die er prachtig uitzien op elk apparaat. Stijlvol design dat perfect past bij jouw merk en doelgroep.",
      features: [
        "Responsive design voor mobiel en desktop",
        "Moderne UI/UX principes",
        "Snelle laadtijden",
        "SEO-geoptimaliseerd",
        "Volledige branding integratie"
      ]
    },
    {
      icon: Bot,
      title: "AI-Automatisering",
      description: "Een extra digitale werkkracht die oneindig opdrachten kan uitvoeren zonder moe te worden. Perfect voor repetitieve taken en workflow optimalisatie.",
      features: [
        "Automatische e-mail responses",
        "Chatbots voor klantenservice",
        "Data verwerking en analyse",
        "Gepersonaliseerde klantinteracties",
        "24/7 beschikbaarheid"
      ]
    },
    {
      icon: Workflow,
      title: "Backend Services (Zonder AI)",
      description: "Traditionele backend automatisering voor bedrijven die geen AI willen gebruiken. Betrouwbaar en effectief.",
      features: [
        "Formulier verwerking",
        "Database management",
        "API integraties",
        "Gebruikersbeheer",
        "Veilige data opslag"
      ]
    },
    {
      icon: Calendar,
      title: "Agenda & Planning Integratie",
      description: "Automatische afspraak planning en synchronisatie met Google Calendar, Outlook en andere systemen.",
      features: [
        "Google Calendar integratie",
        "Automatische bevestigingen",
        "Herinneringen voor klanten",
        "Dubbele boekingen voorkomen",
        "Real-time beschikbaarheid"
      ]
    },
    {
      icon: Smartphone,
      title: "App Development",
      description: "Maatwerk mobiele apps en software oplossingen voor jouw specifieke bedrijfsbehoeften.",
      features: [
        "iOS en Android apps",
        "Progressive Web Apps (PWA)",
        "Cross-platform development",
        "Native performance",
        "App Store publicatie"
      ]
    },
    {
      icon: Palette,
      title: "Branding & Design",
      description: "Volledige branding services om jouw bedrijf een professionele en herkenbare uitstraling te geven.",
      features: [
        "Logo ontwerp",
        "Kleurenschema's",
        "Typografie selectie",
        "Brand guidelines",
        "Marketing materialen"
      ]
    }
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Onze <span className="gradient-text">Diensten</span>
            </h1>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Van modern webdesign tot AI-automatisering - alles wat je nodig hebt voor een professionele online aanwezigheid
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-card border h-full hover:scale-[1.02] transition-transform">
                  <CardHeader>
                    <service.icon className="h-12 w-12 text-primary mb-4" />
                    <CardTitle className="text-2xl">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground/70 mb-4">{service.description}</p>
                    <ul className="space-y-2">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span className="text-sm text-foreground/80">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card border rounded-2xl p-8 md:p-12 text-center"
          >
            <h2 className="text-3xl font-bold mb-4">
              Wat is <span className="gradient-text">AI-Automatisering?</span>
            </h2>
            <p className="text-foreground/70 mb-6 max-w-3xl mx-auto">
              AI-automatisering is als het hebben van een extra werkkracht die nooit moe wordt. Het kan repetitieve 
              taken uitvoeren, klanten helpen, afspraken plannen, en nog veel meer - allemaal automatisch. Maar maak 
              je geen zorgen: je hebt altijd de controle, en we kunnen ook gewone backend services zonder AI leveren 
              als je dat liever hebt.
            </p>
            <Link to="/contact">
              <Button size="lg" className="cursor-pointer neon-glow">
                Vraag een Demo Aan
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
