import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Zap, Shield, Code, Smartphone, Bot, Heart, Target, Users, Star, Quote, Mail, Phone, MapPin, Send, Calendar, Workflow, Palette, ExternalLink } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { toast } from "sonner";

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    business: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    await new Promise(resolve => setTimeout(resolve, 1500));

    toast.success("Bedankt voor je bericht!", {
      description: "We nemen binnen 24 uur contact met je op voor een demo-vergadering."
    });

    setFormData({
      name: "",
      email: "",
      phone: "",
      business: "",
      message: ""
    });
    setIsSubmitting(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const features = [
    {
      icon: Code,
      title: "Modern Webdesign",
      description: "Stijlvolle, gebruiksvriendelijke websites die perfect passen bij jouw merk"
    },
    {
      icon: Bot,
      title: "AI-Automatisering",
      description: "Een extra digitale werkkracht die oneindig opdrachten uitvoert zonder moe te worden"
    },
    {
      icon: Smartphone,
      title: "App Development",
      description: "Maatwerk software en apps voor jouw specifieke bedrijfsbehoeften"
    },
    {
      icon: Zap,
      title: "Backend Services",
      description: "Agenda-integratie, workflow optimalisatie en meer"
    },
    {
      icon: Shield,
      title: "Volledige Branding",
      description: "Jouw huisstijl blijft altijd behouden, geen compromissen"
    },
    {
      icon: Sparkles,
      title: "Professioneel & Warm",
      description: "Persoonlijke service voor lokale ondernemers en kleine bedrijven"
    }
  ];

  const values = [
    {
      icon: Heart,
      title: "Persoonlijk & Warm",
      description: "We begrijpen dat technologie intimiderend kan zijn. Daarom bieden we persoonlijke service met een menselijke touch."
    },
    {
      icon: Target,
      title: "Professioneel & Betrouwbaar",
      description: "Kwaliteit staat voorop. We leveren moderne, professionele websites die echt werken voor jouw bedrijf."
    },
    {
      icon: Users,
      title: "Lokaal & Betrokken",
      description: "We zijn er voor lokale ondernemers, salons en kleine bedrijven die willen groeien met moderne technologie."
    }
  ];

  const services = [
    {
      icon: Code,
      title: "Webdesign & Frontend Development",
      description: "Moderne, responsive websites die er prachtig uitzien op elk apparaat. Stijlvol design dat perfect past bij jouw merk en doelgroep.",
      features: [
        "Responsive design voor mobiel en desktop",
        "Moderne UI/UX principes",
        "Snelle laadtijden",
        "SEO-geoptimaliseerd",
        "Volledige branding integratie"
      ]
    },
    {
      icon: Bot,
      title: "AI-Automatisering",
      description: "Een extra digitale werkkracht die oneindig opdrachten kan uitvoeren zonder moe te worden. Perfect voor repetitieve taken en workflow optimalisatie.",
      features: [
        "Automatische e-mail responses",
        "Chatbots voor klantenservice",
        "Data verwerking en analyse",
        "Gepersonaliseerde klantinteracties",
        "24/7 beschikbaarheid"
      ]
    },
    {
      icon: Workflow,
      title: "Backend Services (Zonder AI)",
      description: "Traditionele backend automatisering voor bedrijven die geen AI willen gebruiken. Betrouwbaar en effectief.",
      features: [
        "Formulier verwerking",
        "Database management",
        "API integraties",
        "Gebruikersbeheer",
        "Veilige data opslag"
      ]
    },
    {
      icon: Calendar,
      title: "Agenda & Planning Integratie",
      description: "Automatische afspraak planning en synchronisatie met Google Calendar, Outlook en andere systemen.",
      features: [
        "Google Calendar integratie",
        "Automatische bevestigingen",
        "Herinneringen voor klanten",
        "Dubbele boekingen voorkomen",
        "Real-time beschikbaarheid"
      ]
    },
    {
      icon: Smartphone,
      title: "App Development",
      description: "Maatwerk mobiele apps en software oplossingen voor jouw specifieke bedrijfsbehoeften.",
      features: [
        "iOS en Android apps",
        "Progressive Web Apps (PWA)",
        "Cross-platform development",
        "Native performance",
        "App Store publicatie"
      ]
    },
    {
      icon: Palette,
      title: "Branding & Design",
      description: "Volledige branding services om jouw bedrijf een professionele en herkenbare uitstraling te geven.",
      features: [
        "Logo ontwerp",
        "Kleurenschema's",
        "Typografie selectie",
        "Brand guidelines",
        "Marketing materialen"
      ]
    }
  ];

  const projects = [
    {
      title: "Salon Elegance",
      category: "Kapsalon Website",
      description: "Moderne website met online afspraak systeem en automatische bevestigingen via WhatsApp.",
      image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&q=80",
      testimonial: "ClickFlow heeft onze online aanwezigheid getransformeerd. Klanten kunnen nu 24/7 afspraken maken!",
      client: "Maria van den Berg"
    },
    {
      title: "Bakkerij De Korenbloem",
      category: "Lokale Bakkerij",
      description: "Website met online bestelsysteem en automatische voorraad updates.",
      image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80",
      testimonial: "Onze online bestellingen zijn met 300% gestegen sinds de nieuwe website!",
      client: "Jan Pieters"
    },
    {
      title: "Fitness Studio Pro",
      category: "Sportschool",
      description: "Complete website met ledenbeheer, rooster en automatische herinneringen.",
      image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80",
      testimonial: "De AI-automatisering bespaart ons uren per week. Fantastisch!",
      client: "Lisa de Vries"
    }
  ];

  const reviews = [
    {
      name: "Maria van den Berg",
      business: "Salon Elegance",
      rating: 5,
      text: "ClickFlow heeft onze online aanwezigheid volledig getransformeerd. De website is prachtig en het automatische afspraaksysteem bespaart ons zoveel tijd. Klanten kunnen nu 24/7 afspraken maken en we krijgen automatisch bevestigingen. Echt een game-changer!",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80"
    },
    {
      name: "Jan Pieters",
      business: "Bakkerij De Korenbloem",
      rating: 5,
      text: "We waren eerst sceptisch over AI, maar het team van ClickFlow heeft alles duidelijk uitgelegd. Nu hebben we een moderne website met een online bestelsysteem dat perfect werkt. Onze omzet is met 300% gestegen!",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80"
    },
    {
      name: "Lisa de Vries",
      business: "Fitness Studio Pro",
      rating: 5,
      text: "De AI-automatisering bespaart ons letterlijk uren per week. Herinneringen gaan automatisch uit, nieuwe leden worden automatisch verwelkomd, en het rooster wordt automatisch bijgewerkt. En het ziet er ook nog eens fantastisch uit!",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80"
    },
    {
      name: "Ahmed Hassan",
      business: "Restaurant De Olijfboom",
      rating: 5,
      text: "Professioneel, betrouwbaar en persoonlijk. ClickFlow heeft precies begrepen wat we nodig hadden. De website past perfect bij onze huisstijl en het reserveringssysteem werkt vlekkeloos.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80"
    },
    {
      name: "Sophie Janssen",
      business: "Yoga Studio Zen",
      rating: 5,
      text: "Ik ben niet technisch aangelegd, maar het team van ClickFlow heeft alles zo duidelijk uitgelegd. De website is precies wat ik wilde en mijn klanten vinden het geweldig. Dank jullie wel!",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80"
    },
    {
      name: "Robert de Jong",
      business: "Autogarage De Jong",
      rating: 5,
      text: "Eindelijk een website die er professioneel uitziet! Het online afspraaksysteem werkt perfect en we krijgen nu veel meer online aanvragen. Zeer tevreden met ClickFlow.",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80"
    }
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section id="home" className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className="inline-block mb-6"
            >
              <div className="glass-card px-4 py-2 rounded-full border">
                <span className="text-sm font-medium gradient-text">✨ Moderne Websites met AI-Automatisering</span>
              </div>
            </motion.div>

            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
              Gebruiksvriendelijke websites met{" "}
              <span className="gradient-text">geïntegreerde AI</span>
            </h1>

            <p className="text-xl text-foreground/70 mb-8 max-w-3xl mx-auto">
              ClickFlow bouwt moderne, professionele websites voor lokale ondernemers, salons en kleine bedrijven. 
              Met optionele AI-automatisering en volledige branding.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="#contact">
                <Button size="lg" className="cursor-pointer group neon-glow">
                  Vraag een Demo-Vergadering Aan
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </a>
              <a href="#services">
                <Button size="lg" variant="outline" className="cursor-pointer glass-card">
                  Bekijk Onze Diensten
                </Button>
              </a>
            </div>
          </motion.div>

          {/* Floating Elements */}
          <div className="relative mt-20 h-96">
            <motion.div
              animate={{ 
                y: [0, -20, 0],
                rotate: [0, 5, 0]
              }}
              transition={{ 
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute top-0 left-1/4 glass-card p-6 rounded-2xl border max-w-xs"
            >
              <Code className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-semibold mb-1">Modern Design</h3>
              <p className="text-sm text-foreground/70">Responsive en stijlvol</p>
            </motion.div>

            <motion.div
              animate={{ 
                y: [0, 20, 0],
                rotate: [0, -5, 0]
              }}
              transition={{ 
                duration: 7,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
              className="absolute top-20 right-1/4 glass-card p-6 rounded-2xl border max-w-xs"
            >
              <Bot className="h-8 w-8 text-primary mb-2" />
              <h3 className="font-semibold mb-1">AI-Automatisering</h3>
              <p className="text-sm text-foreground/70">Extra digitale werkkracht</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
              Wat Wij <span className="gradient-text">Bieden</span>
            </h2>
            <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
              Alles wat je nodig hebt voor een professionele online aanwezigheid
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-card border h-full hover:scale-105 transition-transform cursor-pointer">
                  <CardContent className="p-6">
                    <feature.icon className="h-12 w-12 text-primary mb-4" />
                    <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                    <p className="text-foreground/70">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Over <span className="gradient-text">ClickFlow</span>
            </h2>
            <p className="text-xl text-foreground/70">
              Jouw partner voor moderne websites en slimme automatisering
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="glass-card border rounded-2xl p-8 mb-12"
          >
            <h3 className="text-3xl font-bold mb-6">Wie Zijn Wij?</h3>
            <div className="space-y-4 text-foreground/80 leading-relaxed">
              <p>
                ClickFlow is opgericht met één doel: lokale ondernemers helpen om een professionele online aanwezigheid 
                te creëren zonder de complexiteit van moderne technologie.
              </p>
              <p>
                We geloven dat elke ondernemer, salon of klein bedrijf toegang moet hebben tot moderne, gebruiksvriendelijke 
                websites met de nieuwste technologie. Daarom combineren we stijlvol webdesign met optionele AI-automatisering 
                die echt werkt.
              </p>
              <p>
                Of je nu een kapsalon runt, een lokale winkel hebt, of diensten aanbiedt - wij zorgen ervoor dat jouw 
                online aanwezigheid net zo professioneel is als jouw bedrijf. En met onze AI-automatisering krijg je 
                een extra digitale werkkracht die taken uitvoert terwijl jij je focust op wat je het beste doet.
              </p>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Card className="glass-card border h-full">
                  <CardContent className="p-6 text-center">
                    <value.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                    <p className="text-foreground/70 text-sm">{value.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6 }}
            className="glass-card border rounded-2xl p-8"
          >
            <h3 className="text-3xl font-bold mb-6">Onze Aanpak</h3>
            <div className="space-y-4 text-foreground/80 leading-relaxed">
              <p>
                We beginnen altijd met een demo-vergadering. Eerst laten we je de website zien die we voor jou hebben 
                gemaakt. Daarna bespreken we alles in detail. Geen druk, geen verplichtingen. Als de website niet 
                volledig aan jouw verwachtingen voldoet, is dat geen probleem.
              </p>
              <p>
                Tijdens het hele proces blijft jouw branding en huisstijl behouden. We maken geen compromissen op design 
                of professionaliteit. En als je kiest voor AI-automatisering, leggen we precies uit hoe het werkt en 
                wat het voor jouw bedrijf kan betekenen.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Onze <span className="gradient-text">Diensten</span>
            </h2>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Van modern webdesign tot AI-automatisering - alles wat je nodig hebt voor een professionele online aanwezigheid
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-card border h-full hover:scale-[1.02] transition-transform">
                  <CardHeader>
                    <service.icon className="h-12 w-12 text-primary mb-4" />
                    <CardTitle className="text-2xl">{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground/70 mb-4">{service.description}</p>
                    <ul className="space-y-2">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span className="text-sm text-foreground/80">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card border rounded-2xl p-8 md:p-12 text-center"
          >
            <h3 className="text-3xl font-bold mb-4">
              Wat is <span className="gradient-text">AI-Automatisering?</span>
            </h3>
            <p className="text-foreground/70 mb-6 max-w-3xl mx-auto">
              AI-automatisering is als het hebben van een extra werkkracht die nooit moe wordt. Het kan repetitieve 
              taken uitvoeren, klanten helpen, afspraken plannen, en nog veel meer - allemaal automatisch. Maar maak 
              je geen zorgen: je hebt altijd de controle, en we kunnen ook gewone backend services zonder AI leveren 
              als je dat liever hebt.
            </p>
            <a href="#contact">
              <Button size="lg" className="cursor-pointer neon-glow">
                Vraag een Demo Aan
              </Button>
            </a>
          </motion.div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Ons <span className="gradient-text">Portfolio</span>
            </h2>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Bekijk enkele van de websites die we hebben gemaakt voor tevreden klanten
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-card border overflow-hidden hover:scale-[1.02] transition-transform">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-2xl font-bold mb-1">{project.title}</h3>
                      <p className="text-sm text-foreground/70">{project.category}</p>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <p className="text-foreground/80 mb-4">{project.description}</p>
                    <div className="glass-card border rounded-lg p-4">
                      <div className="flex items-center mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                        ))}
                      </div>
                      <p className="text-sm italic text-foreground/70 mb-2">"{project.testimonial}"</p>
                      <p className="text-sm font-medium">- {project.client}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card border rounded-2xl p-8 text-center"
          >
            <h3 className="text-3xl font-bold mb-4">
              Wil je meer <span className="gradient-text">voorbeelden</span> zien?
            </h3>
            <p className="text-foreground/70 mb-6">
              Tijdens een demo-vergadering laten we je meer projecten zien en bespreken we wat we voor jou kunnen betekenen.
            </p>
            <a 
              href="#contact" 
              className="inline-flex items-center text-primary hover:underline cursor-pointer"
            >
              Vraag een demo aan
              <ExternalLink className="ml-2 h-4 w-4" />
            </a>
          </motion.div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Wat Klanten <span className="gradient-text">Zeggen</span>
            </h2>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Lees de ervaringen van tevreden ondernemers die met ClickFlow werken
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {reviews.map((review, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-card border h-full hover:scale-[1.02] transition-transform">
                  <CardContent className="p-6">
                    <Quote className="h-8 w-8 text-primary/30 mb-4" />
                    
                    <div className="flex items-center mb-4">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                      ))}
                    </div>

                    <p className="text-foreground/80 mb-6 italic">"{review.text}"</p>

                    <div className="flex items-center">
                      <img 
                        src={review.image} 
                        alt={review.name}
                        className="w-12 h-12 rounded-full object-cover mr-4"
                      />
                      <div>
                        <p className="font-semibold">{review.name}</p>
                        <p className="text-sm text-foreground/60">{review.business}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card border rounded-2xl p-8 md:p-12 text-center"
          >
            <h3 className="text-3xl font-bold mb-4">
              Word de volgende <span className="gradient-text">tevreden klant</span>
            </h3>
            <p className="text-foreground/70 mb-6 max-w-2xl mx-auto">
              Sluit je aan bij tientallen ondernemers die al profiteren van een moderne website met ClickFlow
            </p>
            <a href="#contact">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium neon-glow cursor-pointer"
              >
                Vraag een Demo Aan
              </motion.button>
            </a>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Vraag een <span className="gradient-text">Demo-Vergadering</span> Aan
            </h2>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Vul het formulier in en we nemen contact met je op. Eerst laten we je de website zien, 
              daarna bespreken we alles. Geen druk, geen verplichtingen.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-2"
            >
              <Card className="glass-card border">
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Naam *
                        </label>
                        <Input
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          placeholder="Jouw naam"
                          required
                          className="glass-card"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          E-mail *
                        </label>
                        <Input
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="jouw@email.nl"
                          required
                          className="glass-card"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Telefoonnummer
                        </label>
                        <Input
                          name="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={handleChange}
                          placeholder="+31 6 12345678"
                          className="glass-card"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Bedrijfsnaam
                        </label>
                        <Input
                          name="business"
                          value={formData.business}
                          onChange={handleChange}
                          placeholder="Jouw bedrijf"
                          className="glass-card"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Vertel ons over je project *
                      </label>
                      <Textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Waar kunnen we je mee helpen? Heb je al een website? Welke functionaliteiten heb je nodig?"
                        required
                        className="glass-card min-h-32"
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      disabled={isSubmitting}
                      className="w-full cursor-pointer neon-glow"
                    >
                      {isSubmitting ? (
                        "Verzenden..."
                      ) : (
                        <>
                          Verstuur Aanvraag
                          <Send className="ml-2 h-5 w-5" />
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="space-y-6"
            >
              <Card className="glass-card border">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Contactgegevens</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <Mail className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">E-mail</p>
                        <p className="text-sm text-foreground/70">info@clickflow.nl</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <Phone className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">Telefoon</p>
                        <p className="text-sm text-foreground/70">+31 6 12345678</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <MapPin className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">Locatie</p>
                        <p className="text-sm text-foreground/70">Nederland</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Wat gebeurt er nu?</h3>
                  <ol className="space-y-3 text-sm text-foreground/70">
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">1.</span>
                      <span>We nemen binnen 24 uur contact met je op</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">2.</span>
                      <span>We plannen een demo-vergadering in</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">3.</span>
                      <span>Je ziet eerst de website die we voor je maken</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">4.</span>
                      <span>We bespreken alles in detail, geen druk</span>
                    </li>
                  </ol>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}