import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { toast } from "sonner";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    business: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));

    toast.success("Bedankt voor je bericht!", {
      description: "We nemen binnen 24 uur contact met je op voor een demo-vergadering."
    });

    setFormData({
      name: "",
      email: "",
      phone: "",
      business: "",
      message: ""
    });
    setIsSubmitting(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Vraag een <span className="gradient-text">Demo-Vergadering</span> Aan
            </h1>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Vul het formulier in en we nemen contact met je op. Eerst laten we je de website zien, 
              daarna bespreken we alles. Geen druk, geen verplichtingen.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-2"
            >
              <Card className="glass-card border">
                <CardContent className="p-8">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Naam *
                        </label>
                        <Input
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          placeholder="Jouw naam"
                          required
                          className="glass-card"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          E-mail *
                        </label>
                        <Input
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="jouw@email.nl"
                          required
                          className="glass-card"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Telefoonnummer
                        </label>
                        <Input
                          name="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={handleChange}
                          placeholder="+31 6 12345678"
                          className="glass-card"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Bedrijfsnaam
                        </label>
                        <Input
                          name="business"
                          value={formData.business}
                          onChange={handleChange}
                          placeholder="Jouw bedrijf"
                          className="glass-card"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Vertel ons over je project *
                      </label>
                      <Textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Waar kunnen we je mee helpen? Heb je al een website? Welke functionaliteiten heb je nodig?"
                        required
                        className="glass-card min-h-32"
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      disabled={isSubmitting}
                      className="w-full cursor-pointer neon-glow"
                    >
                      {isSubmitting ? (
                        "Verzenden..."
                      ) : (
                        <>
                          Verstuur Aanvraag
                          <Send className="ml-2 h-5 w-5" />
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-6"
            >
              <Card className="glass-card border">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Contactgegevens</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <Mail className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">E-mail</p>
                        <p className="text-sm text-foreground/70">info@clickflow.nl</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <Phone className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">Telefoon</p>
                        <p className="text-sm text-foreground/70">+31 6 12345678</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <MapPin className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">Locatie</p>
                        <p className="text-sm text-foreground/70">Nederland</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Wat gebeurt er nu?</h3>
                  <ol className="space-y-3 text-sm text-foreground/70">
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">1.</span>
                      <span>We nemen binnen 24 uur contact met je op</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">2.</span>
                      <span>We plannen een demo-vergadering in</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">3.</span>
                      <span>Je ziet eerst de website die we voor je maken</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-bold text-primary mr-2">4.</span>
                      <span>We bespreken alles in detail, geen druk</span>
                    </li>
                  </ol>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
