import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Reviews() {
  const reviews = [
    {
      name: "Maria van den Berg",
      business: "Salon Elegance",
      rating: 5,
      text: "ClickFlow heeft onze online aanwezigheid volledig getransformeerd. De website is prachtig en het automatische afspraaksysteem bespaart ons zoveel tijd. Klanten kunnen nu 24/7 afspraken maken en we krijgen automatisch bevestigingen. Echt een game-changer!",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80"
    },
    {
      name: "Jan Pieters",
      business: "Bakkerij De Korenbloem",
      rating: 5,
      text: "We waren eerst sceptisch over AI, maar het team van ClickFlow heeft alles duidelijk uitgelegd. Nu hebben we een moderne website met een online bestelsysteem dat perfect werkt. Onze omzet is met 300% gestegen!",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80"
    },
    {
      name: "Lisa de Vries",
      business: "Fitness Studio Pro",
      rating: 5,
      text: "De AI-automatisering bespaart ons letterlijk uren per week. Herinneringen gaan automatisch uit, nieuwe leden worden automatisch verwelkomd, en het rooster wordt automatisch bijgewerkt. En het ziet er ook nog eens fantastisch uit!",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80"
    },
    {
      name: "Ahmed Hassan",
      business: "Restaurant De Olijfboom",
      rating: 5,
      text: "Professioneel, betrouwbaar en persoonlijk. ClickFlow heeft precies begrepen wat we nodig hadden. De website past perfect bij onze huisstijl en het reserveringssysteem werkt vlekkeloos.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80"
    },
    {
      name: "Sophie Janssen",
      business: "Yoga Studio Zen",
      rating: 5,
      text: "Ik ben niet technisch aangelegd, maar het team van ClickFlow heeft alles zo duidelijk uitgelegd. De website is precies wat ik wilde en mijn klanten vinden het geweldig. Dank jullie wel!",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80"
    },
    {
      name: "Robert de Jong",
      business: "Autogarage De Jong",
      rating: 5,
      text: "Eindelijk een website die er professioneel uitziet! Het online afspraaksysteem werkt perfect en we krijgen nu veel meer online aanvragen. Zeer tevreden met ClickFlow.",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80"
    }
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Wat Klanten <span className="gradient-text">Zeggen</span>
            </h1>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Lees de ervaringen van tevreden ondernemers die met ClickFlow werken
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {reviews.map((review, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-card border h-full hover:scale-[1.02] transition-transform">
                  <CardContent className="p-6">
                    <Quote className="h-8 w-8 text-primary/30 mb-4" />
                    
                    <div className="flex items-center mb-4">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                      ))}
                    </div>

                    <p className="text-foreground/80 mb-6 italic">"{review.text}"</p>

                    <div className="flex items-center">
                      <img 
                        src={review.image} 
                        alt={review.name}
                        className="w-12 h-12 rounded-full object-cover mr-4"
                      />
                      <div>
                        <p className="font-semibold">{review.name}</p>
                        <p className="text-sm text-foreground/60">{review.business}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card border rounded-2xl p-8 md:p-12 text-center"
          >
            <h2 className="text-3xl font-bold mb-4">
              Word de volgende <span className="gradient-text">tevreden klant</span>
            </h2>
            <p className="text-foreground/70 mb-6 max-w-2xl mx-auto">
              Sluit je aan bij tientallen ondernemers die al profiteren van een moderne website met ClickFlow
            </p>
            <a 
              href="/contact"
              className="inline-block"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium neon-glow cursor-pointer"
              >
                Vraag een Demo Aan
              </motion.button>
            </a>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
