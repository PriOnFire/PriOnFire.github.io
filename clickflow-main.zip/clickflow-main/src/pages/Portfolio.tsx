import { motion } from "framer-motion";
import { ExternalLink, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function Portfolio() {
  const projects = [
    {
      title: "Salon Elegance",
      category: "Kapsalon Website",
      description: "Moderne website met online afspraak systeem en automatische bevestigingen via WhatsApp.",
      image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&q=80",
      testimonial: "ClickFlow heeft onze online aanwezigheid getransformeerd. Klanten kunnen nu 24/7 afspraken maken!",
      client: "Maria van den Berg"
    },
    {
      title: "Bakkerij De Korenbloem",
      category: "Lokale Bakkerij",
      description: "Website met online bestelsysteem en automatische voorraad updates.",
      image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80",
      testimonial: "Onze online bestellingen zijn met 300% gestegen sinds de nieuwe website!",
      client: "Jan Pieters"
    },
    {
      title: "Fitness Studio Pro",
      category: "Sportschool",
      description: "Complete website met ledenbeheer, rooster en automatische herinneringen.",
      image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80",
      testimonial: "De AI-automatisering bespaart ons uren per week. Fantastisch!",
      client: "Lisa de Vries"
    }
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Ons <span className="gradient-text">Portfolio</span>
            </h1>
            <p className="text-xl text-foreground/70 max-w-3xl mx-auto">
              Bekijk enkele van de websites die we hebben gemaakt voor tevreden klanten
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-card border overflow-hidden hover:scale-[1.02] transition-transform">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-2xl font-bold mb-1">{project.title}</h3>
                      <p className="text-sm text-foreground/70">{project.category}</p>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <p className="text-foreground/80 mb-4">{project.description}</p>
                    <div className="glass-card border rounded-lg p-4">
                      <div className="flex items-center mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                        ))}
                      </div>
                      <p className="text-sm italic text-foreground/70 mb-2">"{project.testimonial}"</p>
                      <p className="text-sm font-medium">- {project.client}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card border rounded-2xl p-8 text-center"
          >
            <h2 className="text-3xl font-bold mb-4">
              Wil je meer <span className="gradient-text">voorbeelden</span> zien?
            </h2>
            <p className="text-foreground/70 mb-6">
              Tijdens een demo-vergadering laten we je meer projecten zien en bespreken we wat we voor jou kunnen betekenen.
            </p>
            <a 
              href="/contact" 
              className="inline-flex items-center text-primary hover:underline cursor-pointer"
            >
              Vraag een demo aan
              <ExternalLink className="ml-2 h-4 w-4" />
            </a>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
