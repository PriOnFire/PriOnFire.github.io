import { motion } from "framer-motion";
import { Heart, Target, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function About() {
  const values = [
    {
      icon: Heart,
      title: "Persoonlijk & Warm",
      description: "We begrijpen dat technologie intimiderend kan zijn. Daarom bieden we persoonlijke service met een menselijke touch."
    },
    {
      icon: Target,
      title: "Professioneel & Betrouwbaar",
      description: "Kwaliteit staat voorop. We leveren moderne, professionele websites die echt werken voor jouw bedrijf."
    },
    {
      icon: Users,
      title: "Lokaal & Betrokken",
      description: "We zijn er voor lokale ondernemers, salons en kleine bedrijven die willen groeien met moderne technologie."
    }
  ];

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Over <span className="gradient-text">ClickFlow</span>
            </h1>
            <p className="text-xl text-foreground/70">
              Jouw partner voor moderne websites en slimme automatisering
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-card border rounded-2xl p-8 mb-12"
          >
            <h2 className="text-3xl font-bold mb-6">Wie Zijn Wij?</h2>
            <div className="space-y-4 text-foreground/80 leading-relaxed">
              <p>
                ClickFlow is opgericht met één doel: lokale ondernemers helpen om een professionele online aanwezigheid 
                te creëren zonder de complexiteit van moderne technologie.
              </p>
              <p>
                We geloven dat elke ondernemer, salon of klein bedrijf toegang moet hebben tot moderne, gebruiksvriendelijke 
                websites met de nieuwste technologie. Daarom combineren we stijlvol webdesign met optionele AI-automatisering 
                die echt werkt.
              </p>
              <p>
                Of je nu een kapsalon runt, een lokale winkel hebt, of diensten aanbiedt - wij zorgen ervoor dat jouw 
                online aanwezigheid net zo professioneel is als jouw bedrijf. En met onze AI-automatisering krijg je 
                een extra digitale werkkracht die taken uitvoert terwijl jij je focust op wat je het beste doet.
              </p>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Card className="glass-card border h-full">
                  <CardContent className="p-6 text-center">
                    <value.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                    <p className="text-foreground/70 text-sm">{value.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="glass-card border rounded-2xl p-8"
          >
            <h2 className="text-3xl font-bold mb-6">Onze Aanpak</h2>
            <div className="space-y-4 text-foreground/80 leading-relaxed">
              <p>
                We beginnen altijd met een demo-vergadering. Eerst laten we je de website zien die we voor jou hebben 
                gemaakt. Daarna bespreken we alles in detail. Geen druk, geen verplichtingen. Als de website niet 
                volledig aan jouw verwachtingen voldoet, is dat geen probleem.
              </p>
              <p>
                Tijdens het hele proces blijft jouw branding en huisstijl behouden. We maken geen compromissen op design 
                of professionaliteit. En als je kiest voor AI-automatisering, leggen we precies uit hoe het werkt en 
                wat het voor jouw bedrijf kan betekenen.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
